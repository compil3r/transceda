Ola, fulano.

Voce solicitou a troca de senhas, click nesse link para executar. 
{{ url('password/reset/'.$token) }}
